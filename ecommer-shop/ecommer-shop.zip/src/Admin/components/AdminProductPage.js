import React, { useContext, useEffect, useState } from "react";
import { FaBox, FaUsers, FaSignOutAlt } from "react-icons/fa";
import { useOrders } from "../../User/context/OrderContext";
import { UserContext } from "../../User/context/UserContext";
import { useNavigate } from "react-router-dom";

const AdminProductPage = () => {
  const [products, setProducts] = useState(() => {
    const storedProducts = localStorage.getItem("products");
    return storedProducts
      ? JSON.parse(storedProducts)
      : [
          {
            id: 1,
            productId: "1",
            productName: "Caravaggio Read Wall Light",
            productPrice: 60,
            originalPrice: 59,
            sale: true,
            rating: 2,
            descriptions:
              "A stylish and functional wall-mounted reading light, perfect for bedrooms and cozy reading corners.",
            size: "20cm x 15cm x 12cm",
            image: "/images/img_product1.png",
            image1: "/images/img1_product1.png",
            image2: "/images/img2_product1.png",
            quantity: 5,
            categoryType: "",
            createdAt: "2025-01-01T00:00:00Z",
            updatedAt: "2025-01-01T00:00:00Z",
          },
          {
            id: 2,
            productId: "2",
            productName: "Bouquet Flower Vase",
            productPrice: 59,
            originalPrice: null,
            sale: false,
            rating: 4,
            descriptions:
              "A beautifully crafted ceramic vase designed to showcase fresh or dried flowers elegantly.",
            size: "Height 25cm, Diameter 10cm",
            image: "/images/img_product2.png",
            image1: "/images/img1_product2.png",
            image2: "/images/img2_product2.png",
            quantity: 20,
            categoryType: "",
            createdAt: "2025-01-01T00:00:00Z",
            updatedAt: "2025-01-01T00:00:00Z",
          },
          {
            id: 3,
            productId: "3",
            productName: "Egg Dining Table",
            productPrice: 100.0,
            originalPrice: null,
            sale: false,
            rating: 5,
            descriptions:
              "A modern and elegant dining table with a smooth oval surface, perfect for family meals and gatherings.",
            size: "180cm x 90cm x 75cm",
            image: "/images/img_product3.png",
            image1: "/images/img1_product3.png",
            quantity: 10,
            categoryType: "",
            createdAt: "2025-01-01T00:00:00Z",
            updatedAt: "2025-01-01T00:00:00Z",
          },
          {
            id: 4,
            productId: "4",
            productName: "Century Starburst Clock",
            productPrice: 55,
            originalPrice: 60,
            sale: true,
            rating: 4,
            descriptions:
              "A vintage-inspired wall clock with a sunburst design, bringing retro charm to any room.",
            size: "50cm diameter",
            image: "/images/img_product.webp",
            quantity: 15,
            categoryType: "",
            createdAt: "2025-01-01T00:00:00Z",
            updatedAt: "2025-01-01T00:00:00Z",
          },
          {
            id: 5,
            productId: "5",
            productName: "Cubic Plinth",
            productPrice: 135,
            originalPrice: 200,
            sale: true,
            rating: 2,
            descriptions:
              "A minimalist cubic plinth, ideal for displaying art, plants, or decorative items in a modern interior.",
            size: "40cm x 40cm x 40cm",
            image: "/images/img_product.webp",
            quantity: 5,
            categoryType: "",
            createdAt: "2025-01-01T00:00:00Z",
            updatedAt: "2025-01-01T00:00:00Z",
          },
        ];
  });

  const [users, setUsers] = useState(() => {
    const storedUsers = localStorage.getItem("users");
    return storedUsers ? JSON.parse(storedUsers) : [];
  });

  const [formData, setFormData] = useState({
    productName: "",
    productPrice: "",
    quantity: "",
    image: "",
  });

  const [editingId, setEditingId] = useState(null);
  const [activeTab, setActiveTab] = useState("dashboard");
  const handleInput = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const { orders } = useOrders();
  const [orderDetails, setOrderDetails] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Mở/đóng modal chi tiết đơn hàng
  const openOrderDetails = (order) => {
    setOrderDetails(order);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setOrderDetails(null);
  };

  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products));
  }, [products]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingId !== null) {
      setProducts((prev) =>
        prev.map((p) =>
          p.id === editingId ? { ...formData, id: editingId } : p,
        ),
      );
      setEditingId(null);
    } else {
      setProducts((prev) => [
        ...prev,
        { ...formData, id: Date.now(), createdAt: new Date().toISOString() },
      ]);
    }
    setFormData({
      productName: "",
      productPrice: "",
      quantity: "",
      image: "",
    });
  };

  const handleEdit = (product) => {
    setFormData(product);
    setEditingId(product.id);
  };

  const handleDelete = (id) =>
    setProducts((prev) => prev.filter((p) => p.id !== id));

  const handleAddUser = (newUser) => {
    const updatedUsers = [...users, newUser];
    setUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };

  const handleEditUser = (editedUser) => {
    const updatedUsers = users.map((user) =>
      user.id === editedUser.id ? editedUser : user
    );
    setUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };

  const handleDeleteUser = (id) => {
    const updatedUsers = users.filter((user) => user.id !== id);
    setUsers(updatedUsers);
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  };
  

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  };

  const { setUser } = useContext(UserContext);
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen bg-gray-100 overflow-x-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-white shadow-md p-6 space-y-6">
        <h2 className="text-xl font-bold text-gray-700 mb-4">Admin Panel</h2>
        <ul className="space-y-3 text-gray-600">
          <li>
            <div
              onClick={() => setActiveTab("dashboard")}
              className={`flex items-center gap-2 cursor-pointer hover:text-blue-500 ${
                activeTab === "dashboard" ? "text-blue-600 font-semibold" : ""
              }`}
            >
              <FaBox /> Dashboard
            </div>
          </li>
          <li>
            <div
              onClick={() => setActiveTab("products")}
              className={`flex items-center gap-2 cursor-pointer hover:text-blue-500 ${
                activeTab === "products" ? "text-blue-600 font-semibold" : ""
              }`}
            >
              <FaBox /> Quản lý sản phẩm
            </div>
          </li>
          <li>
            <div
              onClick={() => setActiveTab("users")}
              className={`flex items-center gap-2 cursor-pointer hover:text-blue-500 ${
                activeTab === "users" ? "text-blue-600 font-semibold" : ""
              }`}
            >
              <FaUsers /> Quản lý người dùng
            </div>
          </li>
          <li>
            <div
              onClick={handleLogout}
              className="flex items-center gap-2 cursor-pointer text-red-500 hover:text-red-600"
            >
              <FaSignOutAlt /> Đăng xuất
            </div>
          </li>
        </ul>
      </aside>

      {/* Main Content */}
      <div className="bg-white shadow-lg rounded-xl p-8 max-w-screen-lg w-full mx-auto">
        {activeTab === "dashboard" && (
          <div>
            <h2 className="text-2xl font-semibold mb-4 text-center">
              Dashboard
            </h2>

            {/* Sắp xếp đơn hàng theo thời gian tạo, đơn hàng mới nhất lên trên */}
            {orders.length > 0 ? (
              [...orders] // Tạo một bản sao của mảng orders để không thay đổi mảng gốc
                .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)) // Sắp xếp theo thời gian
                .map((order) => (
                  <div
                    key={order.id}
                    className="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 mb-6 rounded-md shadow-md"
                  >
                    <div className="text-sm">
                      <p>
                        <strong>Mã đơn:</strong> #{order.id} -{" "}
                        {new Date(order.createdAt).toLocaleString()}
                      </p>
                      <p>
                        <strong>Phương thức:</strong>{" "}
                        {order.paymentMethod === "cod"
                          ? "Thanh toán khi nhận hàng"
                          : "Chuyển khoản"}
                      </p>
                      <ul className="list-none ml-6 my-2">
                        {order.items.map((item, index) => (
                          <li key={index}>
                            <span>
                              {item.quantity} x {item.productName}
                            </span>
                            <span className="text-gray-600">
                              ($
                              {typeof item.productPrice === "number"
                                ? item.productPrice.toFixed(2)
                                : Number(item.productPrice).toFixed(2)}
                              )
                            </span>
                          </li>
                        ))}
                      </ul>
                      <p>
                        <strong>Tổng cộng:</strong>{" "}
                        <span className="text-green-700 font-semibold">
                          ${order.total.toFixed(2)}
                        </span>
                      </p>
                      <button
                        onClick={() => openOrderDetails(order)}
                        className="mt-4 text-blue-600 hover:underline"
                      >
                        Xem chi tiết
                      </button>
                    </div>
                  </div>
                ))
            ) : (
              <p className="text-center text-gray-500">
                Không có đơn hàng nào.
              </p>
            )}
          </div>
        )}

        {/* Modal Chi Tiết Đơn Hàng */}
        {isModalOpen && orderDetails && (
          <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center z-50">
            <div className="bg-gray p-6 rounded-lg max-w-2xl w-full">
              <h2 className="text-2xl font-semibold mb-4">
                Chi tiết đơn hàng #{orderDetails.id}
              </h2>
              <p>
                <strong>Phương thức thanh toán:</strong>{" "}
                {orderDetails.paymentMethod === "cod"
                  ? "Thanh toán khi nhận hàng"
                  : "Chuyển khoản"}
              </p>
              <ul className="list-none ml-6 my-2">
                {orderDetails.items.map((item, index) => (
                  <li key={index}>
                    <span>
                      {item.quantity} x {item.productName}
                    </span>
                    <span className="text-gray-600">
                      ($
                      {typeof item.productPrice === "number"
                        ? item.productPrice.toFixed(2)
                        : Number(item.productPrice).toFixed(2)}
                      )
                    </span>
                  </li>
                ))}
              </ul>
              <p>
                <strong>Tổng cộng:</strong>{" "}
                <span className="text-green-700 font-semibold">
                  ${orderDetails.total.toFixed(2)}
                </span>
              </p>
              <button
                onClick={closeModal}
                className="mt-4 bg-red-600 text-white px-4 py-2 rounded"
              >
                Đóng
              </button>
            </div>
          </div>
        )}

        {activeTab === "products" && (
          <div>
            {/* <h2 className="text-2xl font-semibold mb-4 text-center">
          Quản lý sản phẩm
        </h2> */}
            {/* Thêm component quản lý sản phẩm ở đây */}
            <div className="p-6 max-w-6xl mx-auto">
              <h1 className="text-4xl font-semibold text-center text-gray-800 mb-8">
                Quản lý sản phẩm
              </h1>

              <form onSubmit={handleSubmit} className="space-y-6 mb-12">
                <div className="grid grid-cols-2 gap-6">
                  <input
                    name="productName"
                    value={formData.productName}
                    onChange={handleInput}
                    placeholder="Tên sản phẩm"
                  />
                  <input
                    name="productPrice"
                    value={formData.productPrice}
                    onChange={handleInput}
                    placeholder="Giá"
                  />
                  <input
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleInput}
                    placeholder="Số lượng"
                  />
                  <input
                    name="image"
                    value={formData.image}
                    onChange={handleInput}
                    placeholder="Link ảnh"
                  />
                </div>

                <div className="text-center">
                  <button
                    type="submit"
                    className="bg-black text-white px-6 py-3 rounded-lg font-medium hover:bg-gray-700 transition-all duration-200"
                  >
                    {editingId !== null ? "Cập nhật sản phẩm" : "Thêm sản phẩm"}
                  </button>
                </div>
              </form>

              <div className="overflow-x-auto bg-white shadow-md rounded-lg">
                <table className="min-w-full table-auto">
                  <thead>
                    <tr className="bg-gray-200 text-gray-600">
                      <th className="px-6 py-3 text-left">Ảnh</th>
                      <th className="px-6 py-3 text-left">Tên sản phẩm</th>
                      <th className="px-6 py-3 text-left">Giá</th>
                      <th className="px-6 py-3 text-left">Số lượng</th>
                      <th className="px-6 py-3 text-left">Hành động</th>
                    </tr>
                  </thead>
                  <tbody>
                    {products.map((product) => (
                      <tr
                        key={product.id}
                        className="border-t hover:bg-gray-50"
                      >
                        <td className="px-6 py-4 text-center">
                          <img
                            src={product.image}
                            alt={product.productName}
                            className="w-16 h-16 object-cover rounded-md"
                          />
                        </td>
                        <td className="px-6 py-4">{product.productName}</td>
                        <td className="px-6 py-4">{`$${product.productPrice}`}</td>
                        <td className="px-6 py-4">{product.quantity}</td>
                        <td className="px-6 py-4 flex justify-center">
                          <button
                            onClick={() => handleEdit(product)}
                            className="text-blue-600 hover:underline mr-4"
                          >
                            Sửa
                          </button>
                          <button
                            onClick={() => handleDelete(product.id)}
                            className="text-red-600 hover:underline"
                          >
                            Xóa
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === "users" && (
          <div className="p-6 max-w-4xl mx-auto">
            <h1 className="text-3xl font-semibold text-center mb-6">
              Quản lý người dùng
            </h1>
            <table className="min-w-full table-auto border border-gray-200">
              <thead className="bg-gray-100">
                <tr>
                  <th className="px-4 py-2">ID</th>
                  <th className="px-4 py-2">Họ tên</th>
                  <th className="px-4 py-2">Email</th>
                  <th className="px-4 py-2">Chức vụ</th>
                  <th className="px-4 py-2">Địa chỉ</th>
                  <th className="px-4 py-2">Số điện thoại</th>
                  <th className="px-6 py-3 text-left">Hành động</th>
                </tr>
              </thead>
              <tbody>
                {users.map((user) => (
                  <tr key={user.id} className="border-t border-gray-200">
                    <td className="px-4 py-2">{user.id}</td>
                    <td className="px-4 py-2">
                      {user.firstName} {user.lastName}
                    </td>
                    <td className="px-4 py-2">{user.email}</td>
                    <td className="px-4 py-2">{user.role}</td>
                    <td className="px-4 py-2">{user.address}</td>
                    <td className="px-4 py-2">
                      {user.phoneNumber ? user.phoneNumber : "Chưa có"}
                    </td>
                    <td className="px-6 py-4 flex justify-center">
                    <button
                            onClick={() => handleAddUser(user)}
                            className="text-blue-600 hover:underline mr-4"
                          >
                            Thêm
                          </button>
                          <button
                            onClick={() => handleEditUser(user)}
                            className="text-blue-600 hover:underline mr-4"
                          >
                            Sửa
                          </button>
                          <button
                            onClick={() => handleDeleteUser(user.id)}
                            className="text-red-600 hover:underline"
                          >
                            Xóa
                          </button>
                        </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminProductPage;
